package com.example.afinal.Review;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.afinal.R;

import java.util.ArrayList;

public class ReviewCommAdapter extends BaseAdapter {

    private Context context;
    private int resource;
    private ArrayList<ReviewCommentItem> items;

    public ReviewCommAdapter() {
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(resource, parent, false);
        }
        final ReviewCommentItem item = items.get(position);
        TextView rev_content = (TextView) convertView.findViewById(R.id.rev_content);
        TextView user_id = (TextView) convertView.findViewById(R.id.user_id);
        TextView rev_write = (TextView) convertView.findViewById(R.id.rev_write);

        rev_content.setText(item.getRev_content());
        user_id.setText(item.getUser_id());
        rev_write.setText((CharSequence) item.getRev_write());

        return convertView;
    }
}