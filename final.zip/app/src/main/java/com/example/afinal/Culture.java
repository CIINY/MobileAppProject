package com.example.afinal;

import java.sql.Date;

public class Culture {

    int cul_id;
    String cul_name;
    String cul_desc;
    String place;
    String start_date;
    String end_date;
    String available_people;
    String cul_picpath;

    public Culture() {
    }

    public Culture(int cul_id, String cul_picpath, String cul_name, String place, String start_date, String end_date) {
        this.cul_id = cul_id;
        this.cul_picpath = cul_picpath;
        this.cul_name = cul_name;
        this.place = place;
        this.start_date = start_date;
        this.end_date = end_date;
    }

    public int getCul_id() {
        return cul_id;
    }

    public void setCul_id(int cul_id) {
        this.cul_id = cul_id;
    }

    public String getCul_name() {
        return cul_name;
    }

    public void setCul_name(String cul_name) {
        this.cul_name = cul_name;
    }

    public String getCul_desc() {
        return cul_desc;
    }

    public void setCul_desc(String cul_desc) {
        this.cul_desc = cul_desc;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public String getStart_date() {
        return start_date;
    }

    public void setStart_date(String start_date) {
        this.start_date = start_date;
    }

    public String getEnd_date() {
        return end_date;
    }

    public void setEnd_date(String end_date) {
        this.end_date = end_date;
    }

    public String getAvailable_people() {
        return available_people;
    }

    public void setAvailable_people(String available_people) {
        this.available_people = available_people;
    }

    public String getCul_picpath() {
        return cul_picpath;
    }

    public void setCul_picpath(String cul_picpath) {
        this.cul_picpath = cul_picpath;
    }
}
