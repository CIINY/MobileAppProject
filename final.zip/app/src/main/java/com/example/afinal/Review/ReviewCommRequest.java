package com.example.afinal.Review;

import androidx.annotation.Nullable;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

public class ReviewCommRequest extends StringRequest {
    final static  private String URL="http://10.0.2.2:8080/reviewCommSelect.php";
    private Map<String,String> map;

    public ReviewCommRequest(String rev_id, String rev_content, String user_id, Timestamp rev_write, int cul_id, Response.Listener<String> listener, @Nullable Response.ErrorListener errorListener) {
        super(Request.Method.POST, URL, listener, null);

        map = new HashMap<>();
        map.put("rev_id", rev_id);
        map.put("rev_content", rev_content);
        map.put("user_id", user_id);
        map.put("rev_write", String.valueOf(rev_write));
        map.put("cul_id", String.valueOf(cul_id));
    }
    @Override
    protected Map<String, String> getParams() throws AuthFailureError {
        return map;
    }
}
