package com.example.afinal;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

public class Register extends AppCompatActivity {

    private DrawerLayout mDrawerLayout;
    private Context context = this;
    private AlertDialog dialog;

    private Button btnSave, check_button;
    EditText nameTxt, idTxt, pwTxt, telNumTxt, emailTxt;
    String name, user_id, user_pw, user_phone, user_email, user_regdate;

    private boolean validate = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_ac);

        nameTxt = findViewById(R.id.name);
        idTxt = findViewById(R.id.userid);
        pwTxt = findViewById(R.id.userpw);
        telNumTxt = findViewById(R.id.userphone);
        emailTxt = findViewById(R.id.userEmail);

        mDrawerLayout = findViewById(R.id.drawer_layout_regi);

        //아이디 중복 체크
        check_button = findViewById(R.id.check_btn);
        check_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validate) {
                    return; //검증완료
                }
                if (idTxt.getText().toString().equals("")) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                    dialog = builder.setMessage("아이디를 입력하세요.").setPositiveButton("확인", null).create();
                    dialog.show();
                    return;
                }
                //검증시작
                Response.Listener<String> responseListener = new Response.Listener<String>(){
                    @Override
                    public void onResponse(String response) {
                        try{
                            Toast.makeText(Register.this, response, Toast.LENGTH_LONG).show();
                            JSONObject jsonResponse = new JSONObject(response);
                            boolean success = jsonResponse.getBoolean("success");
                            System.out.println("boolean: " + success);
                            if(success){//사용할 수 있는 아이디라면
                                AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                                dialog = builder.setMessage("사용할 수 있는 아이디 입니다.")
                                        .setPositiveButton("확인", null)
                                        .create();
                                dialog.show();
                                idTxt.setEnabled(false);//아이디값을 바꿀 수 없도록 함
                                validate = true;//검증완료
                                idTxt.setBackgroundColor(getResources().getColor(R.color.colorGray));
                                check_button.setBackgroundColor(getResources().getColor(R.color.colorGray));
                            }else{//사용할 수 없는 아이디라면
                                EditText userid = (EditText) findViewById(R.id.userid);
                                AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                                dialog = builder.setMessage("이미 사용중인 아이디 입니다.")
                                        .setNegativeButton("확인", null)
                                        .create();
                                userid.setText(null);
                                dialog.show();
                            }

                        }
                        catch(Exception e){
                            e.printStackTrace();
                        }
                    }
                };//Response.Listener 완료
                //Volley 라이브러리를 이용해서 실제 서버와 통신을 구현하는 부분
                ValidateRequest validateRequest = new ValidateRequest(user_id, responseListener);
                RequestQueue queue = Volley.newRequestQueue(Register.this);
                queue.add(validateRequest);
            }
        });

        //회원가입 정보 저장
        btnSave = findViewById(R.id.regiBtn);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name = nameTxt.getText().toString();
                user_id = idTxt.getText().toString();
                user_pw = pwTxt.getText().toString();
                user_phone = telNumTxt.getText().toString();
                user_email = emailTxt.getText().toString();

                //아이디 중복체크 했는지 확인
                if (!validate) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                    dialog = builder.setMessage("아이디 중복확인을 해주세요.").setNegativeButton("확인", null).create();
                    dialog.show();
                    return;
                }
                if (name.equals("") || user_id.equals("") || user_pw.equals("")  || user_phone.equals("") || user_email.equals("")) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                    dialog = builder.setMessage("빈칸을 채워주십시오!")
                            .setPositiveButton("확인", null)
                            .create();
                    dialog.show();
                    return;
                }

                //회원가입 시작
                Response.Listener<String> responseListener = new Response.Listener<String>(){
                    @Override
                    public void onResponse(String response) {
                        try{
                            Log.e("response", response);
                            JSONObject jsonResponse = new JSONObject(response);
                            boolean success = jsonResponse.getBoolean("success");
                            System.out.println("boolean: " + success);
                            if(success){//사용할 수 있는 아이디라면
                                AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                                dialog = builder.setMessage("회원가입 완료")
                                        .setPositiveButton("OK", null)
                                        .create();
                                dialog.show();
                                Intent intent = new Intent(getApplicationContext(), Login.class);
                                startActivity(intent);
                                finish();//액티비티를 종료시킴(회원등록 창을 닫음)
                            }else{//사용할 수 없는 아이디라면
                                AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                                dialog = builder.setMessage("회원가입 실패")
                                        .setNegativeButton("OK", null)
                                        .create();
                                dialog.show();
                            }

                        }
                        catch(Exception e){
                            e.printStackTrace();
                        }
                    }
                };//Response.Listener 완료

                //Volley 라이브러리를 이용해서 실제 서버와 통신을 구현하는 부분
                RegisterRequest registerRequest = new RegisterRequest(name, user_id, user_pw, user_phone, user_email, responseListener);
                RequestQueue queue = Volley.newRequestQueue(Register.this);
                queue.add(registerRequest);


//                dataInsert();
//
//                Toast.makeText(context, "회원가입 완료!", Toast.LENGTH_LONG).show();
//                Intent LoginInt = new Intent(getApplicationContext(), Login.class);
//                startActivity(LoginInt);
//                finish();
            }
        });

        //로그인 페이지로 돌아가기
        Button backBtn = (Button) findViewById(R.id.backBtn);

        //로그인 페이지로 돌아가기 버튼
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "돌아가기", Toast.LENGTH_LONG).show();
                Intent backInt = new Intent(getApplicationContext(), Login.class);
                startActivity(backInt);
                finish();
            }
        });
    }
    @Override
    protected void onStop() {
        super.onStop();
        if(dialog != null){
            dialog.dismiss();
            dialog = null;
        }
    }
//    public void dataInsert() {
//        new Thread() {
//            public void run() {
//                try {
//                    URL url = new URL("http://10.0.2.2/Register.php/");
//                    HttpURLConnection http = (HttpURLConnection) url.openConnection();
//                    http.setDefaultUseCaches(false);
//                    http.setDoInput(true);
//                    http.setRequestMethod("POST");
//                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");
//
//                    StringBuffer buffer = new StringBuffer();
//                    buffer.append("name").append("=").append(name).append("&user_id=").append(user_id).append("&user_pw=").append(user_pw).append("&user_phone=").append(user_phone).append("&user_email=").append(user_email);
//                    System.out.println(name);
//                    System.out.println(user_id);
//                    System.out.println(user_pw);
//                    System.out.println(user_phone);
//                    System.out.println(user_email);
//                    OutputStreamWriter osw = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
//                    osw.write(buffer.toString());
//                    osw.flush();
//
//                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
//                    final BufferedReader reader = new BufferedReader(tmp);
//                    while (reader.readLine() != null) {
//                        System.out.println(reader.readLine());
//                    }
//
//                } catch (Exception e) {
//                    System.out.println("인터넷에 문제가 있습니다.");
//                    Log.e("dataInsert()", "인터넷 문제 발생", e);
//                }
//            }
//        }.start();
//    }
}
