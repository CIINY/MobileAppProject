package com.example.afinal;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.afinal.search.Search;

import org.w3c.dom.Text;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class CultureListAdapter extends BaseAdapter {

    TextView cul_name, place, start_date, end_date;
    ImageView cul_picpath;

    ArrayList<Culture> cultureList = new ArrayList<Culture>();

    public CultureListAdapter() {

    }

    //출력할 총갯수를 설정하는 메소드
    @Override
    public int getCount() {
        return cultureList.size();
    }

    //특정 정보(?)를 반환하는 메소드
    @Override
    public Object getItem(int position) {
        return cultureList.get(position);
    }


    //아이템별 아이디를 반환하는 메소드
    @Override
    public long getItemId(int position) {
        return position;
    }

    //가장 중요한 부분
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final int pos = position;
        final Context context = parent.getContext();

        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.list_item, parent, false);
        }

        //뷰에 다음 컴포넌트들을 연결시켜줌
        cul_name = (TextView) convertView.findViewById(R.id.cul_name);
        place = (TextView) convertView.findViewById(R.id.place);
        start_date = (TextView) convertView.findViewById(R.id.startTxt);
        end_date = (TextView) convertView.findViewById(R.id.endTxt);
        cul_picpath = (ImageView) convertView.findViewById(R.id.cul_picpath);

        Culture listItem = cultureList.get(position);

        Glide.with(convertView).asBitmap().load(listItem.getCul_picpath()).into(cul_picpath);
        cul_name.setText(listItem.getCul_name());
        place.setText(listItem.getPlace());
        start_date.setText(listItem.getStart_date());
        end_date.setText(listItem.getEnd_date());

        //만든뷰를 반환함
        return convertView;
    }

    public void addItem(int cul_id, String cul_picpath, String cul_name, String place, String start_date, String end_date) {

        Culture item = new Culture();

        item.setCul_id(cul_id);
        item.setCul_picpath(cul_picpath);
        item.setCul_name(cul_name);
        item.setPlace(place);
        item.setStart_date(start_date);
        item.setEnd_date(end_date);

        cultureList.add(item);
    }
}