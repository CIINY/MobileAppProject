package com.example.afinal.Time;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.afinal.R;
import com.example.afinal.search.Search;

import java.util.ArrayList;

public class TimeAdapter extends BaseAdapter {

    TextView time, person;
    RadioButton chk;

    ArrayList<TIME> timeList = new ArrayList<TIME>();

    public TimeAdapter() {

    }

    @Override
    public int getCount() {
        return timeList.size();
    }

    @Override
    public Object getItem(int position) {
        return timeList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final int pos = position;
        final Context context = parent.getContext();

        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = ((Activity)context).getLayoutInflater().inflate(R.layout.time_item, parent, false);
        } else {

        }

        time = (TextView) convertView.findViewById(R.id.time);
//        chk = (RadioButton) convertView.findViewById(R.id.chk);
        person = (TextView) convertView.findViewById(R.id.person);


        TIME listItem = timeList.get(position);

        time.setText(listItem.getTime_slot());
        person.setText(listItem.getAvailable_people());

        return convertView;
    }

    public void addItem(String time, int person) {

        TIME item = new TIME();

        item.setTime_slot(time);
        item.setAvailable_people(person);

        timeList.add(item);
    }

}
