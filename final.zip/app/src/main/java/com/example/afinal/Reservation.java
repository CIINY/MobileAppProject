package com.example.afinal;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.afinal.Time.TIME;
import com.example.afinal.Time.TimeAdapter;

import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

public class Reservation extends AppCompatActivity {

    private Context context = this;
    String myJSON;
    JSONArray time = null;

    String user_id;
    Button resBtn;
    TextView nameTxt;

    String cul_id, cul_picpath, cul_name, place, start_date, end_date;

    private static final String TAG_RESULTS = "result";
    private static final String TAG_ID = "time_id";
    private static final String TAG_TIME = "time_slot";
    private static final String TAG_PEOPLE = "available_people";
    private static final String TAG_EMAIL = "user_email";

    TimeAdapter adapter = new TimeAdapter();
    ArrayList<HashMap<String, String>> timeList;
    ListView time_lv;

    EditText etPerson, etDate, etTime;
    String perStr, dateStr, timeStr;
    TextView startTxt, endTxt;

    String cul_desc;

    private ArrayList<TIME> TIMEList;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reservation);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE );

        //툴바관련
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(false); // 기존 title 지우기
        actionBar.setDisplayHomeAsUpEnabled(true); // 뒤로가기 버튼 만들기

//        UserDTO userDto = new UserDTO();
//        String email = userDto.getUser_email();
//        System.out.println("email=" + email);

        //예약할 전시회 이름이 보여질 TextView
        nameTxt = (TextView) findViewById(R.id.culNameTxt);

        //전시회 관람 날짜가 보여질 TextView
        startTxt = (TextView) findViewById(R.id.startTxt);  //관람시작날짜
        endTxt = (TextView) findViewById(R.id.endTxt);      //관람마지막날짜

        timeList = new ArrayList<HashMap<String, String>>();

        etPerson = (EditText) findViewById(R.id.etPerson);  //예약인원수
        etDate = (EditText) findViewById(R.id.etDate);      //예약날짜
        etTime = (EditText) findViewById(R.id.etTime);      //예약시간

        //값 가져오기
        Intent intent = getIntent();
        user_id = intent.getStringExtra("user_id");

        //전시회 값 가져오기
        cul_id = intent.getStringExtra("cul_id");
        cul_picpath = intent.getStringExtra("cul_picpath");
        cul_name = intent.getStringExtra("cul_name");
        place = intent.getStringExtra("place");
        start_date = intent.getStringExtra("start_date");
        end_date = intent.getStringExtra("end_date");

        cul_desc = intent.getStringExtra("culDesc");

        //전시회 정보 가져오기
        nameTxt.setText(cul_name);
        startTxt.setText(start_date);
        endTxt.setText(end_date);

        timeSelect();

        //시간
        TIMEList = new ArrayList<TIME>();

        //예약버튼
        resBtn = (Button) findViewById(R.id.res_btn);
        resBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                perStr = etPerson.getText().toString();
                dateStr = etDate.getText().toString();
                timeStr = etTime.getText().toString();

                if(perStr.isEmpty() || dateStr.isEmpty() || timeStr.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "빈칸을 채우세요.", Toast.LENGTH_SHORT).show();
                } else {
                    resInsert(user_id, cul_id, cul_name, place, timeStr, dateStr, perStr);
                    Toast.makeText(Reservation.this, "예약이 완료되었습니다.", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getApplicationContext(), CultureDetail.class);
                    intent.putExtra("user_id", user_id);
                    intent.putExtra("cul_id", cul_id);
                    intent.putExtra("cul_name", cul_name);
                    intent.putExtra("cul_desc", cul_desc);
                    intent.putExtra("cul_picpath", cul_picpath);
                    intent.putExtra("place", place);
                    intent.putExtra("start_date", start_date);
                    intent.putExtra("end_date", end_date);
                    startActivity(intent);
                    finish();
//                    Intent intent = new Intent(getApplicationContext(), SendEmail.class);
//                    intent.putExtra("user_id", user_id);
//                    intent.putExtra("cul_name", cul_name);
//                    intent.putExtra("timeStr", timeStr);
//                    intent.putExtra("dateStr", dateStr);
//                    intent.putExtra("perStr", perStr);
//                    startActivity(intent);
//                    finish();
                }
            }
        });
    }

    //예약하기
    public void resInsert(String user_id, String cul_id, String cul_name, String place, String resTime, String resDate, String res_people){
        new Thread(){
            public  void run(){
                try {
                    URL url = new URL("http://10.0.2.2:8080/reservation.php/");
                    HttpURLConnection http = (HttpURLConnection) url.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type","application/x-www-form-urlencoded");

                    StringBuffer buffer = new StringBuffer();
                    buffer.append("res_num").append("=").append("res_num").append("/").append(user_id).append("/").append(cul_id).append("/").append(cul_name).append("/").append(place).append("/").append(resTime).append("/").append(resDate).append("/").append(res_people).append("/");

                    OutputStreamWriter osw = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    osw.write(buffer.toString());
                    osw.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    final BufferedReader reader = new BufferedReader(tmp);
                    while (reader.readLine() !=null ) {
                        System.out.println(reader.readLine());
                    }

                }catch (Exception e){
                    Log.e("error","인터넷 문제 발생", e);
                }
            }
        }.start();
    }

    protected void showList(ArrayList<String[]> al) {
        try {
            for (int i = 0; i < al.size(); i++) {
                String time_id = null;
                String time_slot = null;
                String available_people = null;
                for(int j = 0; j < al.get(i).length; j++){
                    time_id = al.get(i)[0];
                    time_slot = al.get(i)[1];
                    available_people = al.get(i)[2];
                }

                HashMap<String, String> cul = new HashMap<String, String>();

                cul.put(TAG_ID, time_id);
                cul.put(TAG_TIME, time_slot);
                cul.put(TAG_PEOPLE, available_people);

                timeList.add(cul);
            }
            ListAdapter adapter = new SimpleAdapter(
                    Reservation.this, timeList, R.layout.time_item,
                    new String[]{TAG_PEOPLE},
                    new int[]{R.id.person}
            );
            time_lv.setAdapter(adapter);
        } catch (Exception e) {
            Log.d(TAG_ID, "showResult : ", e);
        }
    }

    //시간대 보여주기
    public void timeSelect(){
        new Thread(){
            public  void run(){
                try {
                    URL url = new URL("http://10.0.2.2:8080/time.php/");
                    HttpURLConnection http = (HttpURLConnection) url.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type","application/x-www-form-urlencoded");

                    StringBuffer buffer = new StringBuffer();

                    OutputStreamWriter osw = new OutputStreamWriter(http.getOutputStream(), "utf-8");
                    osw.write(buffer.toString());
                    osw.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "utf-8");
                    final BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();

                    String str;
                    while ((str = reader.readLine()) != null ) {
                        builder.append(str);
                    }
                    String resultData = builder.toString();

                    final String[] sR1 = resultData.split("#");
                    ArrayList<String[]> result = new ArrayList<>();
                    for(String sR2 : sR1){
                        final String[] sR3 = sR2.split("///");
                        if(sR3.length > 1) {
                            result.add(sR3);
//                            System.out.println(sR2);
                            String time_id = sR3[0];
                            String time_slot = sR3[1];
                            String available_peopl = sR3[2];
                        }
                    }
                    showList(result);
                }catch (Exception e){
                    Log.e("error","인터넷 문제 발생", e);
                }
            }
        }.start();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Intent intent = new Intent(context, CultureDetail.class);
                intent.putExtra("user_id", user_id);
                intent.putExtra("cul_id", cul_id);
                intent.putExtra("cul_picpath", cul_picpath);
                intent.putExtra("cul_name", cul_name);
                intent.putExtra("place", place);
                intent.putExtra("start_date", start_date);
                intent.putExtra("end_date", end_date);
                startActivity(intent);
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
