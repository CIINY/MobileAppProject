package com.example.afinal.Manager;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.afinal.CultureDetail;
import com.example.afinal.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

public class ManagerCulture extends AppCompatActivity {

    private Context context = this;

    String myJSON;

    private static final String TAG_RESULTS = "result";
    private static final String TAG_ID = "cul_id";
    private static final String TAG_IMAGE = "cul_picpath";
    private static final String TAG_NAME = "cul_name";
    private static final String TAG_PLACE = "place";
    private static final String TAG_DESC = "cul_desc";
    private static final String TAG_START = "start_date";
    private static final String TAG_END = "end_date";

    JSONArray culture = null;
    ArrayList<HashMap<String, String>> cultureList;
    ListView list;

    Button btnSearch;

    String value;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.manager_culture);

        list = (ListView) findViewById(R.id.admin_cul_lv);
        cultureList = new ArrayList<HashMap<String, String>>();
        getData("http://10.0.2.2:8080/adminSelectCulture.php");

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                HashMap<String, String> map = (HashMap<String, String>) list.getItemAtPosition(position);
                String cul_id = map.get(TAG_ID);
                value = map.get(TAG_ID);


                //FrameLayout과 LayoutParams 생성
                FrameLayout container = new FrameLayout(ManagerCulture.this);
                FrameLayout.LayoutParams params = new  FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                //params에 margin 추가
                params.leftMargin = getResources().getDimensionPixelSize(R.dimen.dialog_margin);
                params.rightMargin = getResources().getDimensionPixelSize(R.dimen.dialog_margin);

                final AlertDialog.Builder builder = new AlertDialog.Builder(ManagerCulture.this);
                builder.setTitle("문화생활 관리");
                builder.setView(container);    //AlertDialog에 적용하기

                builder.setPositiveButton("수정하기", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent = new Intent(getApplicationContext(), ManagerCultureUpdate.class);
                        intent.putExtra("cul_id", map.get(TAG_ID));
                        intent.putExtra("cul_name", map.get(TAG_NAME));
                        intent.putExtra("cul_desc", map.get(TAG_DESC));
                        intent.putExtra("place", map.get(TAG_PLACE));
                        intent.putExtra("start_date", map.get(TAG_START));
                        intent.putExtra("end_date", map.get(TAG_END));
                        intent.putExtra("cul_picpath", map.get(TAG_IMAGE));
                        Toast.makeText(getApplicationContext(), "수정페이지로 이동합니다.", Toast.LENGTH_SHORT).show();
                        startActivity(intent);
                        finish();
                    }
                });
                builder.setNegativeButton("취소", null);
                builder.setNeutralButton("삭제", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //문화생활삭제
                        cultureDelete();
                        Toast.makeText(ManagerCulture.this, "문화생활 삭제완료. 해당페이지를 나갔다 돌아오세요.", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.show();
            }
        });

        //툴바
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(false); // 기존 title 지우기
        actionBar.setDisplayHomeAsUpEnabled(true); // 뒤로가기 버튼 만들기

        //문화생활 등록
        btnSearch = (Button) findViewById(R.id.btnInsert);
        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ManagerCultureRegister.class);
                startActivity(intent);
                finish();
            }
        });

    }

    //문화생활 삭제하기
    public void cultureDelete() {
        new Thread() {
            public void run() {
                try {
                    URL url = new URL("http://10.0.2.2:8080/adminDeleteCulture.php/");
                    HttpURLConnection http = (HttpURLConnection) url.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");

                    StringBuffer buffer = new StringBuffer();
                    buffer.append("key").append("=").append(value);

                    OutputStreamWriter outStream = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    outStream.write(buffer.toString());
                    outStream.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String str;

                    while ((str = reader.readLine()) != null) {
                        builder.append(str + "\n");
                    }
                    String resultData = builder.toString();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }


    //문화생활 리스트 보여주기
    protected void showList() {
        try {
            JSONObject jsonObj = new JSONObject(myJSON);
            culture = jsonObj.getJSONArray(TAG_RESULTS);

            for (int i = 0; i < culture.length(); i++) {
                JSONObject c = culture.getJSONObject(i);
                String cul_id = c.getString(TAG_ID);
                String cul_picpath = c.getString(TAG_IMAGE);
                String cul_name = c.getString(TAG_NAME);
                String place = c.getString(TAG_PLACE);
                String cul_desc = c.getString(TAG_DESC);
                String start_date = c.getString(TAG_START);
                String end_date = c.getString(TAG_END);

                HashMap<String, String> cul = new HashMap<String, String>();

                cul.put(TAG_ID, cul_id);
                cul.put(TAG_IMAGE, cul_picpath);
                cul.put(TAG_NAME, cul_name);
                cul.put(TAG_PLACE, place);
                cul.put(TAG_DESC, cul_desc);
                cul.put(TAG_START, start_date);
                cul.put(TAG_END, end_date);

                cultureList.add(cul);
            }
            ListAdapter adapter = new SimpleAdapter(
                    ManagerCulture.this, cultureList, R.layout.manager_item,
                    new String[]{TAG_IMAGE, TAG_NAME, TAG_PLACE, TAG_START, TAG_END},
                    new int[]{R.id.cul_picpath, R.id.cul_name, R.id.place, R.id.start_date, R.id.end_date}
            );

            list.setAdapter(adapter);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void getData(String url) {
        class GetDataJSON extends AsyncTask<String, Void, String> {
            @Override
            protected String doInBackground(String... params) {
                String uri = params[0];

                BufferedReader bufferedReader = null;
                try {
                    java.net.URL url = new URL(uri);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    StringBuilder sb = new StringBuilder();

                    bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));

                    String json;
                    while ((json = bufferedReader.readLine()) != null) {
                        sb.append(json + "\n");
                    }

                    return sb.toString().trim();
                } catch (Exception e) {
                    return null;
                }

            }
            @Override
            protected void onPostExecute (String result){
                myJSON = result;
                showList();
            }
        }
        GetDataJSON g = new GetDataJSON();
        g.execute(url);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                Intent intent = new Intent(context, ManagerMain.class);
                startActivity(intent);
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
