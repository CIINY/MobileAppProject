package com.example.afinal;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class UserListAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<User> userList;

    public UserListAdapter() {
        this.context = context;
        this.userList = userList;
    }

    //출력할 총갯수를 설정하는 메소드
    @Override
    public int getCount() {
        return userList.size();
    }

    //특정 정보(?)를 반환하는 메소드
    @Override
    public Object getItem(int i) {
        return userList.get(i);
    }

    //아이템별 아이디를 반환하는 메소드
    @Override
    public long getItemId(int i) {
        return i;
    }

    //가장 중요한 부분
    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View v = View.inflate(context, R.layout.activity_main, null);

        //뷰에 다음 컴포넌트들을 연결시켜줌
        TextView user_id = (TextView) v.findViewById(R.id.user_id);
        TextView name = (TextView) v.findViewById(R.id.name);
        TextView user_regdate = (TextView) v.findViewById(R.id.user_regdate);

        user_id.setText(userList.get(i).getUser_id());
        name.setText(userList.get(i).getName());
        user_regdate.setText((CharSequence) userList.get(i).getUser_regdate());

        //이렇게하면 fidnViewWithTag를 쓸 수 있음 없어도 되는 문장임
        v.setTag(userList.get(i).getUser_id());

        //만든뷰를 반환함
        return v;
    }
}