package com.example.afinal.Review;

import java.sql.Timestamp;

public class ReviewCommentItem {

    int rev_id;
    String rev_content;
    Timestamp rev_write;
    String user_id;
    int cul_id;

    public ReviewCommentItem() {
    }

    public ReviewCommentItem(int rev_id, String rev_content, String user_id, int cul_id) {
        this.rev_id = rev_id;
        this.rev_content = rev_content;
        this.user_id = user_id;
        this.cul_id = cul_id;
    }

    public int getRev_id() {
        return rev_id;
    }

    public void setRev_id(int rev_id) {
        this.rev_id = rev_id;
    }

    public String getRev_content() {
        return rev_content;
    }

    public void setRev_content(String rev_content) {
        this.rev_content = rev_content;
    }

    public Timestamp getRev_write() {
        return rev_write;
    }

    public void setRev_write(Timestamp rev_write) {
        this.rev_write = rev_write;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public int getCul_id() {
        return cul_id;
    }

    public void setCul_id(int cul_id) {
        this.cul_id = cul_id;
    }
}
