package com.example.afinal;

import java.sql.Timestamp;

public class User {

    String user_id;
    String name;
    Timestamp user_regdate;

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Timestamp getUser_regdate() {
        return user_regdate;
    }

    public void setUser_regdate(Timestamp user_regdate) {
        this.user_regdate = user_regdate;
    }
}
