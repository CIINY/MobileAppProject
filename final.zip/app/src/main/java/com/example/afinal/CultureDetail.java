package com.example.afinal;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.bumptech.glide.Glide;
import com.example.afinal.Review.ReviewCommAdapter;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

public class CultureDetail extends AppCompatActivity {

    private Context context = this;
    private AlertDialog dialog;

    Button btnReser;
    TextView culName, placeTxt, culDesc, startTxt, endTxt;
    ImageView picpath;
    int rev_id;

    // 댓글 관련
    Button btnComm;
    String rev_content;

    // 댓글 수정, 삭제 버튼
    Button editBtn, deleteBtn;

    String culID;       //메인화면에서 가져온 전시회의 아이디

    private static final String TAG_RESULTS = "result";
    private static final String TAG_ID = "cul_id";
    private static final String TAG_CONTENT = "rev_content";
    private static final String TAG_USERID = "user_id";
    private static final String TAG_WRITEDATE = "rev_write";
    private static final String TAG_START = "start_date";
    private static final String TAG_END = "end_date";
    private static final String TAG_REVIEWID = "rev_id";

    ReviewCommAdapter adapter = new ReviewCommAdapter();

    ArrayList<HashMap<String, String>> reviewList;
    ListView review_lv;

    String user_id;

    //댓글 수정, 삭제 관련
    EditText et;
    String value2;

    ArrayList<Culture> culture_lv = new ArrayList<Culture>();

    String cul_id, cul_picpath, cul_name, place, start_date, end_date;

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.culture_detail);

        //툴바관련
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(false); // 기존 title 지우기
        actionBar.setDisplayHomeAsUpEnabled(true); // 뒤로가기 버튼 만들기

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE );

        picpath = (ImageView) findViewById(R.id.cul_picpath);
        culName = (TextView) findViewById(R.id.cul_name);
        placeTxt = (TextView) findViewById(R.id.place);
        culDesc = (TextView) findViewById(R.id.cul_desc);
        startTxt = (TextView) findViewById(R.id.startTxt);
        endTxt = (TextView) findViewById(R.id.endTxt);

        //로그인한 유저 정보 데이터 가져오는 부분
        Intent intent1 = getIntent();
        user_id = intent1.getStringExtra("user_id");

        //문화생활 정보 데이터 가져와 보여주는 부분
        Intent intent = getIntent();
        cul_id = intent.getStringExtra("cul_id");
        cul_picpath = intent.getStringExtra("cul_picpath");
        cul_name = intent.getStringExtra("cul_name");
        place = intent.getStringExtra("place");
        start_date = intent.getStringExtra("start_date");
        end_date = intent.getStringExtra("end_date");

        culID = cul_id;
        picpath.setImageDrawable(Drawable.createFromPath(cul_picpath));
        culName.setText(cul_name);
        placeTxt.setText(place);
        culDesc.setText(cul_name);
        startTxt.setText(start_date);
        endTxt.setText(end_date);

        final String imgStr = cul_picpath;
        Glide.with(this).asBitmap().load(imgStr).into(picpath);

        review_lv = (ListView) findViewById(R.id.review_lv);
        reviewList = new ArrayList<HashMap<String, String>>();

        //댓글리스트뷰 가져오기
        dataSelect();

        //예약버튼
        btnReser = (Button) findViewById(R.id.btnReser);
        btnReser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Reservation.class);
                intent.putExtra("user_id", user_id);
                intent.putExtra("cul_id", cul_id);
                intent.putExtra("cul_name", cul_name);
                intent.putExtra("cul_picpath", cul_picpath);
                intent.putExtra("cul_desc", String.valueOf(culDesc));
                intent.putExtra("place", place);
                intent.putExtra("start_date", start_date);
                intent.putExtra("end_date", end_date);
                startActivity(intent);
                finish();
            }
        });

        //댓글 수정, 삭제
        review_lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                //댓글 작성한 회원아이디 정보 가져오기
                HashMap<String,String> map = (HashMap<String,String>) review_lv.getItemAtPosition(position);
                String value = map.get(TAG_USERID);
                value2 = map.get(TAG_REVIEWID);

                if(user_id.equals(value)) {
                    et = new EditText(CultureDetail.this);   //EditText 생성
                    //FrameLayout과 LayoutParams 생성
                    FrameLayout container = new FrameLayout(CultureDetail.this);
                    FrameLayout.LayoutParams params = new  FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                    //params에 margin 추가
                    params.leftMargin = getResources().getDimensionPixelSize(R.dimen.dialog_margin);
                    params.rightMargin = getResources().getDimensionPixelSize(R.dimen.dialog_margin);
                    //EditText에 params 속성 적용하기
                    et.setLayoutParams(params);
                    //FrameLayout에 EditText 추가하기
                    container.addView(et);

                    final AlertDialog.Builder builder = new AlertDialog.Builder(CultureDetail.this);
                    builder.setTitle("댓글 관리");
                    builder.setMessage("수정할 내용을 입력하세요.");
                    builder.setView(container);    //AlertDialog에 적용하기

                    builder.setPositiveButton("수정하기", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            String editCom = et.getText().toString();
                            if(editCom.isEmpty()) {
                                Toast.makeText(CultureDetail.this, "빈칸을 채우세요.", Toast.LENGTH_SHORT).show();
                            } else if (editCom.length() > 50){
                                Toast.makeText(CultureDetail.this, "최대입력수를 초과했습니다.", Toast.LENGTH_SHORT).show();
                            } else {
                                //댓글수정
                                reviewUpdate();
                                Toast.makeText(CultureDetail.this, "수정완료.", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                    builder.setNegativeButton("취소", null);
                    builder.setNeutralButton("삭제", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //댓글삭제
                            reviewDelete();
                            Toast.makeText(CultureDetail.this, "댓글 삭제완료", Toast.LENGTH_SHORT).show();
                        }
                    });
                    builder.show();
                } else {    //해당 댓글 작성자의 아이디와 로그인한 회원의 아이디가 일치하지않을때
                    Toast.makeText(CultureDetail.this, "권한이 없습니다.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //리뷰댓글작성버튼
        btnComm = (Button) findViewById(R.id.btnComm);
        btnComm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 키보드를 내리기 위한 InputMethodManager 객체 선언
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);

                EditText etContent = (EditText) findViewById(R.id.etComm);
                rev_content = etContent.getText().toString();

                if (rev_content.equals("")) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(CultureDetail.this);
                    dialog = builder.setMessage("빈칸을 채워주십시오!")
                            .setPositiveButton("확인", null)
                            .create();
                    dialog.show();
                    return;
                } else {
                    commInsert(rev_content, user_id, culID);
                    Toast.makeText(CultureDetail.this, "댓글이 등록되었습니다.", Toast.LENGTH_SHORT).show();
                    etContent.setText("");
                    Intent intent = new Intent(getApplicationContext(), CultureDetail.class);
                    startActivity(intent);
                    finish();
                }
                // 키보드 내리기
                imm.hideSoftInputFromWindow(etContent.getWindowToken(), 0);
            }
        });


    }

    //댓글수정하기
    public void reviewUpdate() {
        new Thread() {

            public void run() {
                try {
                    URL url = new URL("http://10.0.2.2:8080/reviewUpdate.php/");
                    HttpURLConnection http = (HttpURLConnection) url.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");

                    StringBuffer buffer = new StringBuffer();
                    buffer.append("key").append("=").append(et.getText().toString()).append("/").append(value2).append("/");

                    OutputStreamWriter outStream = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    outStream.write(buffer.toString());
                    outStream.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String str = "";

                    while ((str = reader.readLine()) != null) {
                        builder.append(str);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

    //댓글 삭제하기
    public void reviewDelete() {
        new Thread() {
            public void run() {
                try {
                    URL url = new URL("http://10.0.2.2:8080/reviewDelete.php/");
                    HttpURLConnection http = (HttpURLConnection) url.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");

                    StringBuffer buffer = new StringBuffer();
                    buffer.append("key").append("=").append(value2);

                    OutputStreamWriter outStream = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    outStream.write(buffer.toString());
                    outStream.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String str;

                    while ((str = reader.readLine()) != null) {
                        builder.append(str + "\n");
                    }
                    String resultData = builder.toString();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }
    
    //댓글리스트뷰 보여주기
    protected void showList(ArrayList<String[]> al) {
        try {
            for (int i = 0; i < al.size(); i++) {
                String rev_id = null;
                String rev_content = null;
                String user_id = null;
                String rev_write = null;
                for(int j = 0; j < al.get(i).length; j++){
                    rev_id = al.get(i)[0];
                    rev_content = al.get(i)[1];
                    user_id = al.get(i)[2];
                    rev_write = al.get(i)[3];
                }

                HashMap<String, String> cul = new HashMap<String, String>();

                cul.put(TAG_REVIEWID, rev_id);
                cul.put(TAG_CONTENT, rev_content);
                cul.put(TAG_USERID, user_id);
                cul.put(TAG_WRITEDATE, rev_write);

                reviewList.add(cul);
            }
            ListAdapter adapter = new SimpleAdapter(
                    CultureDetail.this, reviewList, R.layout.review_item,
                    new String[]{TAG_CONTENT, TAG_USERID, TAG_WRITEDATE},
                    new int[]{ R.id.rev_content, R.id.user_id, R.id.rev_write}
            );
            review_lv.setAdapter(adapter);
        } catch (Exception e) {
            Log.d(TAG_ID, "showResult : ", e);
        }
    }

    //댓글리스트 보여주기
    public void dataSelect(){
        new Thread(){
            public  void run(){
                try {
                    URL url = new URL("http://10.0.2.2:8080/reviewCommSelect.php/");
                    HttpURLConnection http = (HttpURLConnection) url.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type","application/x-www-form-urlencoded");
                    StringBuffer buffer = new StringBuffer();
                    buffer.append("cul_id").append("=").append(culID);
                    OutputStreamWriter osw = new OutputStreamWriter(http.getOutputStream(), "utf-8");
                    osw.write(buffer.toString());
                    osw.flush();
                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "utf-8");
                    final BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String str;
                    while ((str = reader.readLine()) != null ) {
                        builder.append(str);
                    }
                    String resultData = builder.toString();
                    final String[] sR1 = resultData.split("#");
                    ArrayList<String[]> result = new ArrayList<>();
                    for(String sR2 : sR1){
                        final String[] sR3 = sR2.split("///");
                        if(sR3.length > 1) {
                            result.add(sR3);
                            System.out.println(sR2);
                            String rev_id = sR3[0];
                            String content = sR3[1];
                            String writer = sR3[2];
                            String date = sR3[3];
                        }
                    }
                    showList(result);
                }catch (Exception e){
                    Log.e("error","인터넷 문제 발생", e);
                }
            }
        }.start();
    }

    //댓글 등록하기
    public void commInsert(String rev_content, String user_id, String cul_id){
        new Thread(){
            public  void run(){
                try {
                    URL url = new URL("http://10.0.2.2:8080/reviewInsert.php/");
                    HttpURLConnection http = (HttpURLConnection) url.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type","application/x-www-form-urlencoded");

                    StringBuffer buffer = new StringBuffer();
                    buffer.append("rev_id").append("=").append("rev_id").append("/").append(rev_content).append("/").append(user_id).append("/").append(cul_id).append("/");

                    OutputStreamWriter osw = new OutputStreamWriter(http.getOutputStream(), "UTF-8");

                    osw.write(buffer.toString());
                    osw.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    final BufferedReader reader = new BufferedReader(tmp);
                    while (reader.readLine() !=null ) {
                        System.out.println(reader.readLine());
                    }
                }catch (Exception e){
                    Log.e("error","인터넷 문제 발생", e);
                }
            }
        }.start();
    }

    /**
     * actionbar backbutton event
     * 이거때문에 며칠동안 아이디값 조회를 못해서 튕겼었음 ^^ (메인액티비티로 이동할떄)
     * 버튼 이벤트로 다시 유저아이디를 메인액티비티로 넘겨줌 ㅎ.ㅎ
     * @param item MenuItem
     * @return boolean
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                Intent intent = new Intent(context, MainActivity.class);
                intent.putExtra("user_id", user_id);
                startActivity(intent);
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
