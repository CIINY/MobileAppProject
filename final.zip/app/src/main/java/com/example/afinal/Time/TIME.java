package com.example.afinal.Time;

public class TIME {

    int time_id;
    String time_slot;
    int available_people;

    TIME() {
        this.time_id = time_id;
        this.time_slot = time_slot;
        this.available_people = available_people;
    }

    public int getTime_id() {
        return time_id;
    }

    public void setTime_id(int time_id) {
        this.time_id = time_id;
    }

    public String getTime_slot() {
        return time_slot;
    }

    public void setTime_slot(String time_slot) {
        this.time_slot = time_slot;
    }

    public int getAvailable_people() {
        return available_people;
    }

    public void setAvailable_people(int available_people) {
        this.available_people = available_people;
    }
}
