package com.example.afinal.search;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.afinal.Culture;
import com.example.afinal.CultureDetail;
import com.example.afinal.MainActivity;
import com.example.afinal.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;


public class SearchPage extends AppCompatActivity {

//    //화면에 보여줄 String형을 Key로 value를 Integer로 설정
//    private HashMap<String, Integer> map = new HashMap<String, Integer>();

    String myJSON;

    private static final String TAG_RESULTS = "result";
    private static final String TAG_ID = "cul_id";
    private static final String TAG_IMAGE = "cul_picpath";
    private static final String TAG_NAME = "cul_name";
    private static final String TAG_PLACE = "place";
    private static final String TAG_DESC = "cul_desc";
    private static final String TAG_START = "start_date";
    private static final String TAG_END = "end_date";

    JSONArray culture = null;
    ArrayList<HashMap<String, String>> searchList;
    ListView search_lv;

    private TextView etDate;
    private DatePickerDialog.OnDateSetListener callbackMethod;

    private DrawerLayout mDrawerLayout;
    private Context context = this;

    String user_id;

    String searchTxt;
    EditText etSearch;
    ListView lvSearch;
    Button btnSerch;
    Handler handler = new Handler();

    SearchAdapter adapter = new SearchAdapter();

    int count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search_page);

        // 툴바
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(false); // 기존 title 지우기
        actionBar.setDisplayHomeAsUpEnabled(true); // 뒤로가기 버튼 만들기

        //로그인한 유저 정보 데이터 가져오는 부분
        Intent intent1 = getIntent();
        user_id = intent1.getStringExtra("user_id");

        //검색결과가 뜰 리스트뷰
        search_lv = (ListView) findViewById(R.id.search_lv);
        searchList = new ArrayList<HashMap<String, String>>();


        //검색버튼
        etSearch = (EditText) findViewById(R.id.etSearch);
        searchTxt = etSearch.getText().toString();

        Button btnSearch = (Button) findViewById(R.id.btnSearch);
        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchCulture();
            }
        });

    }

    public void searchCulture() {
        new Thread() {
            public void run() {
                try {
                    URL url = new URL("http://10.0.2.2:8080/searchCulture.php/");
                    HttpURLConnection http = (HttpURLConnection) url.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");
                    StringBuffer buffer = new StringBuffer();
                    buffer.append("cul_name").append("=").append(etSearch.getText().toString());
                    OutputStreamWriter outStream = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    outStream.write(buffer.toString());
                    outStream.flush();
                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String str;
                    while ((str = reader.readLine()) != null) {
                        builder.append(str);
                    }
                    String resultData = builder.toString();
                    final String[] sR1 = resultData.split("#");
                    count = sR1.length;
                    Log.e("Array" + sR1.length, String.valueOf(count));
                    handler.post(new Runnable() {

                        @Override
                        public void run() {
                            adapter.searchList.clear();
                            adapter.notifyDataSetChanged();

                            for (int i = 1; i < count; i++) {
                                final String[] sR2 = sR1[i].split("///");
                                Log.v("Array" + sR2[0], String.valueOf(sR2.length));
                                adapter.addItem(Integer.parseInt(sR2[0]), sR2[1], sR2[2], sR2[3], sR2[4], sR2[5]);
                            }
                            search_lv.setAdapter(adapter);
                            search_lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                @Override
                                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                    Culture item = (Culture) parent.getItemAtPosition(position);
                                    Intent i = new Intent(getApplicationContext(), CultureDetail.class);
                                    int cul_id = item.getCul_id();
                                    String cul_picpath = item.getCul_picpath();
                                    String cul_name = item.getCul_name();
                                    String place = item.getPlace();
                                    String start_date = item.getStart_date();
                                    String end_date = item.getEnd_date();
                                    i.putExtra("cul_id", cul_id);
                                    i.putExtra("cul_picpath", cul_picpath);
                                    i.putExtra("cul_name", cul_name);
                                    i.putExtra("place", place);
                                    i.putExtra("start_date", start_date);
                                    i.putExtra("end_date", end_date);
                                    startActivity(i);
                                }
                            });
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

    //액션바 뒤로가기
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                Intent homeP = new Intent(context, MainActivity.class);
                homeP.putExtra("user_id", user_id);
                System.out.println("user값:" + user_id);
                startActivity(homeP);
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
