package com.example.afinal;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.afinal.Manager.ManagerLogin;
import com.example.afinal.dto.UserDto;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class Login extends AppCompatActivity {

    private DrawerLayout mDrawerLayout;
    private Context context = this;
    private AlertDialog dialog;

    Button loginBtn, regiBtn;
    EditText et_Id, et_Pwd;
    Handler handler = new Handler();

    int count;
    String user_id, user_pw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_ac);

        regiBtn = (Button)findViewById(R.id.regiBtn);
        TextView manBtn = (TextView)findViewById(R.id.manBtn);

        et_Id = findViewById(R.id.etID);
        et_Pwd = findViewById(R.id.etPwd);

        // 관리자로그인창으로 이동
        manBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "관리자 로그인 화면으로 이동합니다.", Toast.LENGTH_LONG).show();
                Intent manInt = new Intent(getApplicationContext(), ManagerLogin.class);
                startActivity(manInt);
                finish();
            }
        });

        // 로그인버튼
        loginBtn = (Button)findViewById(R.id.loginBtn);
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                user_id = et_Id.getText().toString();
                user_pw = et_Pwd.getText().toString();

                if (user_id.equals("") || user_pw.equals("")) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(Login.this);
                    dialog = builder.setMessage("빈칸을 채워주십시오!")
                            .setPositiveButton("확인", null)
                            .create();
                    dialog.show();
                    return;
                }
                dataLogin();
            }
        });

        // 회원가입창으로 이동
        regiBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "회원가입 화면으로 이동합니다.", Toast.LENGTH_LONG).show();
                Intent RegiInt = new Intent(getApplicationContext(), Register.class);
                startActivity(RegiInt);
                finish();
            }
        });
    }
    public void dataLogin() {
        new Thread() {
            public void run() {
                try{
                    user_id = et_Id.getText().toString();
                    user_pw = et_Pwd.getText().toString();

                    URL url = new URL("http://10.0.2.2:8080/Login.php/");
                    HttpURLConnection http = (HttpURLConnection) url.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");

                    StringBuffer buffer = new StringBuffer();
                    buffer.append("key").append("=").append(user_id).append("/").append(user_pw).append("/");

                    OutputStreamWriter outStream = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    outStream.write(buffer.toString());
                    outStream.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String str;

                    while ((str = reader.readLine()) != null) {
                        builder.append(str + "\n");
                    }
                    String resultData = builder.toString();
                    final String[] sResult = resultData.split("/");

                    count = sResult.length;
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if(count == 1) {
                                Toast.makeText(getApplicationContext(), "아이디 혹은 비밀번호가 틀렸습니다.", Toast.LENGTH_SHORT).show();
                            } else {
                                UserDto userDto = new UserDto();
                                userDto.setUser_id(sResult[0]);
                                userDto.setUser_password(sResult[1]);
                                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                                i.putExtra("obj", userDto);
                                i.putExtra("user_id", sResult[0]);
                                i.putExtra("user_pw", sResult[1]);
                                startActivity(i);
                                finish();
                                Toast.makeText(getApplicationContext(), sResult[0] + "님이 로그인하셨습니다.", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }
}
