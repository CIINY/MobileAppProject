package com.example.afinal.Manager;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.afinal.R;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class ManagerCultureRegister extends AppCompatActivity {

    private DrawerLayout mDrawerLayout;
    private Context context = this;

    Button insertBtn;

    EditText imageURL, culture_name, culture_desc, culture_place, culture_startDate, culture_endDate;
    String url, name, desc, place, start, end;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.manager_culture_register);

        //툴바
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(false); // 기존 title 지우기
        actionBar.setDisplayHomeAsUpEnabled(true); // 뒤로가기 버튼 만들기

        insertBtn = (Button) findViewById(R.id.insertBtn);

        imageURL = (EditText) findViewById(R.id.imageURL);
        culture_name = (EditText) findViewById(R.id.culture_name);
        culture_desc = (EditText) findViewById(R.id.culture_desc);
        culture_place = (EditText) findViewById(R.id.culture_place);
        culture_startDate = (EditText) findViewById(R.id.culture_startDate);
        culture_endDate = (EditText) findViewById(R.id.culture_endDate);

        insertBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                url = imageURL.getText().toString();
                name = culture_name.getText().toString();
                desc = culture_desc.getText().toString();
                place = culture_place.getText().toString();
                start = culture_startDate.getText().toString();
                end = culture_endDate.getText().toString();

                cultureInsert(name, desc, place, start, end, url);
                Intent intent = new Intent(getApplicationContext(), ManagerCulture.class);
                Toast.makeText(getApplicationContext(), "등록 완료!", Toast.LENGTH_SHORT).show();
                startActivity(intent);
                finish();
            }
        });

    }

    //문화생활 등록하기
    public void cultureInsert(String cul_name, String cul_desc, String place, String start_date, String end_date, String cul_picpath){
        new Thread(){
            public  void run(){
                try {
                    URL url = new URL("http://10.0.2.2:8080/adminCultureInsert.php/");
                    HttpURLConnection http = (HttpURLConnection) url.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type","application/x-www-form-urlencoded");

                    StringBuffer buffer = new StringBuffer();
                    buffer.append("key").append("=").append("cul_id").append("/").append(cul_name).append("/").append(cul_desc).append("/").append(place).append("/")
                                                    .append(start_date).append("/").append(end_date).append("/").append(cul_picpath).append("/");

                    OutputStreamWriter osw = new OutputStreamWriter(http.getOutputStream(), "UTF-8");

                    osw.write(buffer.toString());
                    osw.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    final BufferedReader reader = new BufferedReader(tmp);
                    while (reader.readLine() !=null ) {
                        System.out.println(reader.readLine());
                    }
                }catch (Exception e){
                    Log.e("error","인터넷 문제 발생", e);
                }
            }
        }.start();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                Intent intent = new Intent(context, ManagerCulture.class);
                startActivity(intent);
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
