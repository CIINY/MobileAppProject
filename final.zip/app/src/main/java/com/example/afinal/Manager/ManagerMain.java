package com.example.afinal.Manager;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.afinal.R;

public class ManagerMain extends AppCompatActivity {

    Button btnUserInquiry, btnCultureMgt, btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.managermain_ac);

        //회원조회 버튼
        btnUserInquiry = (Button) findViewById(R.id.btnUserInquiry);
        btnUserInquiry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ManagerUserInquiry.class);
                startActivity(intent);
                finish();
            }
        });

        //문화생활 관리페이지 이동 버튼
        btnCultureMgt = (Button) findViewById(R.id.btnCultureMgt);
        btnCultureMgt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ManagerCulture.class);
                startActivity(intent);
                finish();
            }
        });

        
        //로그아웃 버튼
        btnLogout = (Button) findViewById(R.id.btnLogout);
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ManagerLogin.class);
                startActivity(intent);
                finish();
            }
        });

    }
}
