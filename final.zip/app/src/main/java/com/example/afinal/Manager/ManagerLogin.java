package com.example.afinal.Manager;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.afinal.Login;
import com.example.afinal.R;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class ManagerLogin extends AppCompatActivity {

    private DrawerLayout mDrawerLayout;
    private Context context = this;
    private AlertDialog dialog;

    EditText etId, etPw;
    String admin_id, admin_pw;

    int count;
    Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.managerlogin_ac);

        Button loginBtn = (Button) findViewById(R.id.loginBtn);
        Button backBtn = (Button) findViewById(R.id.backBtn);

        etId = (EditText) findViewById(R.id.adminId);
        etPw = (EditText) findViewById(R.id.adminPw);

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "돌아가기", Toast.LENGTH_LONG).show();
                Intent backInt = new Intent(getApplicationContext(), Login.class);
                startActivity(backInt);
                finish();
            }
        });

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                admin_id = etId.getText().toString();
                admin_pw = etPw.getText().toString();

                if (admin_id.equals("") || admin_pw.equals("")) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(ManagerLogin.this);
                    dialog = builder.setMessage("빈칸을 채워주십시오!")
                            .setPositiveButton("확인", null)
                            .create();
                    dialog.show();
                    return;
                } else {
                    dataLogin();
                    Toast.makeText(getApplicationContext(), "로그인 되었습니다.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void bt_Login(View v) {
        try {
            admin_id = etId.getText().toString();
        } catch (NullPointerException e) {
            Log.e("err", e.getMessage());
        }
        loginDB lDB = new loginDB();
        lDB.execute();
    }

    public class loginDB extends AsyncTask<Void, Integer, Void> {

        @Override
        protected Void doInBackground(Void... unused) {

            /* 인풋 파라메터값 생성 */
            String param = "admin_id=" + admin_id + "";
            Log.e("POST", param);
            try {
                /* 서버연결 */
                URL url = new URL(
                        "http://10.0.2.2:8080/adminLogin.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                conn.setRequestMethod("POST");
                conn.setDoInput(true);
                conn.connect();

                /* 안드로이드 -> 서버 파라메터값 전달 */
                OutputStream outs = conn.getOutputStream();
                outs.write(param.getBytes("UTF-8"));
                outs.flush();
                outs.close();

                /* 서버 -> 안드로이드 파라메터값 전달 */
                InputStream is = null;
                BufferedReader in = null;
                String data = "";

                is = conn.getInputStream();
                in = new BufferedReader(new InputStreamReader(is), 8 * 1024);
                String line = null;
                StringBuffer buff = new StringBuffer();
                while ((line = in.readLine()) != null) {
                    buff.append(line + "\n");
                }
                data = buff.toString().trim();

                /* 서버에서 응답 */
                Log.e("RECV DATA", data);

                if (data.equals("0")) {
                    Log.e("RESULT", "성공적으로 처리되었습니다!");
                } else {
                    Log.e("RESULT", "에러 발생! ERRCODE = " + data);
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }
    }

    public void dataLogin() {
        new Thread() {
            public void run() {
                try{
                    admin_id = etId.getText().toString();
                    admin_pw = etPw.getText().toString();

                    URL url = new URL("http://10.0.2.2:8080/adminLogin.php/");
                    HttpURLConnection http = (HttpURLConnection) url.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");

                    StringBuffer buffer = new StringBuffer();
                    buffer.append("key").append("=").append(admin_id).append("/").append(admin_pw).append("/");

                    OutputStreamWriter outStream = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    outStream.write(buffer.toString());
                    outStream.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String str;

                    while ((str = reader.readLine()) != null) {
                        builder.append(str + "\n");
                    }
                    String resultData = builder.toString();
                    final String[] sResult = resultData.split("/");

                    count = sResult.length;
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if(count == 1) {
                                Toast.makeText(getApplicationContext(), "아이디 혹은 비밀번호가 틀렸습니다.", Toast.LENGTH_SHORT).show();
                            } else {
                                Intent i = new Intent(getApplicationContext(), ManagerMain.class);
                                i.putExtra("admin", sResult);
                                startActivity(i);
                                finish();
                                Toast.makeText(getApplicationContext(), sResult[0] + "님이 로그인하셨습니다.", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }
}
