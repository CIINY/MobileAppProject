package com.example.afinal;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class EditProfile extends AppCompatActivity {

    private DrawerLayout mDrawerLayout;
    private Context context = this;
    private AlertDialog dialog;

    UserDTO userDto = new UserDTO();
    Handler handler = new Handler();

    String id = userDto.getUser_id();
    String pw = userDto.getUser_id();
    String eMail = userDto.getUser_id();
    String telNum = userDto.getUser_id();

    String user_id;      //로그인 아이디 데이터
    String name, userid, userpw, userphone, userEmail;
    EditText etName, etPW, etPhone, etEmail;
    TextView pro_userid;

    Button updateBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_profile);

        Intent intent = getIntent();
        user_id = intent.getStringExtra("user_id");

        etName = (EditText) findViewById(R.id.eTname);
        etPW = (EditText) findViewById(R.id.eTuserpw);
        etPhone = (EditText) findViewById(R.id.eTuserphone);
        etEmail = (EditText) findViewById(R.id.eTuserEmail);

        pro_userid = (TextView) findViewById(R.id.pro_userid);
        pro_userid.setText(user_id);

        //툴바
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(false); // 기존 title 지우기
        actionBar.setDisplayHomeAsUpEnabled(true); // 뒤로가기 버튼 만들기

        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout2);

        updateBtn = (Button) findViewById(R.id.updateBtn);
        updateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(etName.equals("") || etPW.equals("") || etPhone.equals("") || etEmail.equals("")) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(EditProfile.this);
                    dialog = builder.setMessage("아이디를 입력하세요.").setPositiveButton("확인", null).create();
                    dialog.show();
                    return;
                } else {
                    dataUpdate();
                    Toast.makeText(EditProfile.this, "수정 완료", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }

    public void dataUpdate() {
        new Thread() {

            public void run() {
                try {
                    URL url = new URL("http://10.0.2.2/userUpdate.php/");
                    HttpURLConnection http = (HttpURLConnection) url.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");

                    StringBuffer buffer = new StringBuffer();
                    buffer.append("key").append("=")
                            .append(etName.getText().toString()).append("/")
                            .append(user_id).append("/")
                            .append(etPW.getText().toString()).append("/")
                            .append(etPhone.getText().toString()).append("/")
                            .append(etEmail.getText().toString());
                    System.out.println(etName.getText().toString());
                    System.out.println(user_id);
                    System.out.println(etPW.getText().toString());
                    System.out.println(etPhone.getText().toString());
                    System.out.println(etEmail.getText().toString());

                    OutputStreamWriter outStream = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    outStream.write(buffer.toString());
                    outStream.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String str = "";

                    while ((str = reader.readLine()) != null) {
                        builder.append(str);
                    }

//                    final String resultData = builder.toString();
//                    final String[] sResult = resultData.split("/");

                    handler.post(new Runnable() {
                        @Override
                        public void run() {

                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

//    //수정
//    void dataUpdate() {
//        new Thread() {
//            public void run() {
//                try {
//
//                    name = etName.getText().toString();
//                    userid = pro_userid.getText().toString();
//                    userpw = etPW.getText().toString();
//                    userphone = etPhone.getText().toString();
//                    userEmail = etEmail.getText().toString();
//
//                    URL setURL = new URL("Http://10.0.2.2/userUpdate.php/");
//                    HttpURLConnection http;
//                    http = (HttpURLConnection) setURL.openConnection();
//                    http.setDefaultUseCaches(false);
//                    http.setDoInput(true);
//                    http.setRequestMethod("POST");
//                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");
//                    StringBuffer buffer = new StringBuffer();
//                    buffer.append("user_id").append("=").append(name).append("/").append(userid).append("/").append(userpw).append("/").append(userphone).append("/").append(userEmail).append("/");
//                    OutputStreamWriter outStream = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
//                    outStream.write(buffer.toString());
//                    outStream.flush();
//                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
//                    final BufferedReader reader = new BufferedReader(tmp);
//                    StringBuilder builder = new StringBuilder();
//                    String str, result;
//                    while ((str = reader.readLine()) != null) {
//                        builder.append(str + "\n");
//                    }
//                    result = builder.toString();
//                    String[] sResult = result.split("/");
//                    etName.setText(sResult[0]);
//                    etPW.setText(sResult[1]);
//                    etPhone.setText(sResult[2]);
//                    etEmail.setText(sResult[3]);
//                }catch(Exception e){
//                    Log.e("dataUpdate()", "수정 에러 발생", e);
//                }
//            }
//        }.start();
//    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                Intent myP=new Intent(context, Mypage.class);
                myP.putExtra("user_id", user_id);
                startActivity(myP);
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
