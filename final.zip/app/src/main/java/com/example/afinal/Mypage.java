package com.example.afinal;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

public class Mypage extends AppCompatActivity {

    private DrawerLayout mDrawerLayout;
    private Context context = this;

    TextView userID;

    String user_id, user_pw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mypage_ac);

        //로그인한 유저 정보 데이터 가져오는 부분
        Intent intent = getIntent();
        user_id = intent.getStringExtra("user_id");
        user_pw = intent.getStringExtra("user_pw");
        System.out.println("user_id=" + user_id);
        System.out.println("user_pw=" + user_pw);

        //툴바
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(false); // 기존 title 지우기
        actionBar.setDisplayHomeAsUpEnabled(true); // 뒤로가기 버튼 만들기
        actionBar.setHomeAsUpIndicator(R.drawable.ic_baseline_menu_24); //뒤로가기 버튼 이미지 지정


        userID = (TextView) findViewById(R.id.userIdTxt);
        userID.setText(user_id);

        Button infobtn = (Button)findViewById(R.id.info);

        infobtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent InfoInt = new Intent(getApplicationContext(), EditProfile.class);
                InfoInt.putExtra("user_id", user_id);
                startActivity(InfoInt);
                finish();
            }
        });

        //예약상세목록으로 이동
        Button myReser = (Button)findViewById(R.id.myReser);
        myReser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Reservation_Info.class);
                intent.putExtra("user_id", user_id);
                startActivity(intent);
                finish();
            }
        });

        Button myPlogoutbtn = (Button)findViewById(R.id.myPlogoutbtn);
        myPlogoutbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder=new AlertDialog.Builder(context);
                builder.setTitle("Logout");
                builder.setMessage("로그아웃 하시겠습니까?");

                builder.setPositiveButton("예(YES)", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // 이부분 나중에 MainActivit.class가 아니라 로그인페이지로 바꾸자
                        Intent intent=new Intent(context, Login.class);
                        startActivity(intent);
                        finish();
                    }
                });
                builder.setNegativeButton("취소(CANCEL)", null);
                builder.show();
            }
        });

        Button byebtn = (Button)findViewById(R.id.byebtn);
        byebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), UserQuit.class);
                intent.putExtra("user_id", user_id);
                intent.putExtra("user_pw", user_pw);
                startActivity(intent);
                finish();
            }
        });

        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout_myP);

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                int id = menuItem.getItemId();
                String title = menuItem.getTitle().toString();

                AlertDialog.Builder builder=new AlertDialog.Builder(context);
                builder.setTitle("Logout");
                builder.setMessage("로그아웃 하시겠습니까?");

                if (id == R.id.myPage) {
                    Toast.makeText(context, title + ": 현재페이지 입니다.", Toast.LENGTH_SHORT).show();

                } else if (id == R.id.mainPage) {
                    Intent homeInt=new Intent(context, MainActivity.class);
                    homeInt.putExtra("user_id", user_id);
                    startActivity(homeInt);
                    finish();
                } else if (id == R.id.logout) {
                    //Toast.makeText(context, title + ": 로그아웃 시도중", Toast.LENGTH_SHORT).show();
                    builder.setPositiveButton("예(YEs)", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // 이부분 나중에 MainActivit.class가 아니라 로그인페이지로 바꾸자 그리고 finish()넣기
                            Intent intent=new Intent(context, Login.class);
                            startActivity(intent);
                            finish();
                        }
                    });
                    builder.setNegativeButton("취소(Cencel)", null);
                    builder.show();
                }
                DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout_myP);
                drawer.closeDrawer(GravityCompat.START);

                return true;
            }
        });
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home: { // 왼쪽 상단 버튼 눌렀을 때
                mDrawerLayout.openDrawer(GravityCompat.START);
                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }
}
