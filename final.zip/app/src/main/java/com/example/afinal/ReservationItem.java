package com.example.afinal;

public class ReservationItem {

    int res_num;
    String user_id;
    String cul_id;
    String cul_name;
    String place;
    String resDate;
    String resTime;
    String resPerson;

    public ReservationItem() {
    }

    public int getRes_num() {
        return res_num;
    }

    public void setRes_num(int res_num) {
        this.res_num = res_num;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getCul_id() {
        return cul_id;
    }

    public void setCul_id(String cul_id) {
        this.cul_id = cul_id;
    }

    public String getCul_name() {
        return cul_name;
    }

    public void setCul_name(String cul_name) {
        this.cul_name = cul_name;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public String getResDate() {
        return resDate;
    }

    public void setResDate(String resDate) {
        this.resDate = resDate;
    }

    public String getResTime() {
        return resTime;
    }

    public void setResTime(String resTime) {
        this.resTime = resTime;
    }

    public String getResPerson() {
        return resPerson;
    }

    public void setResPerson(String resPerson) {
        this.resPerson = resPerson;
    }
}
