package com.example.afinal.Manager;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.afinal.R;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;

public class ManagerCultureUpdate extends AppCompatActivity {

    private Context context = this;

    EditText imgUrl, name, desc, culPlace, start, end;

    String culID;
    String img, Cname, Cdesc, Cplace, Cstart, Cend;

    Button updateBn;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.manager_culture_update);

        //툴바관련
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(false); // 기존 title 지우기
        actionBar.setDisplayHomeAsUpEnabled(true); // 뒤로가기 버튼 만들기

        Intent intent = getIntent();

        String cul_id = intent.getStringExtra("cul_id");
        String cul_name = intent.getStringExtra("cul_name");
        String cul_picpath = intent.getStringExtra("cul_picpath");
        String cul_desc = intent.getStringExtra("cul_desc");
        String place = intent.getStringExtra("place");
        String start_date = intent.getStringExtra("start_date");
        String end_date = intent.getStringExtra("end_date");


        imgUrl = (EditText) findViewById(R.id.imageURL);
        name = (EditText) findViewById(R.id.culture_name);
        desc = (EditText) findViewById(R.id.culture_desc);
        culPlace = (EditText) findViewById(R.id.culture_place);
        start = (EditText) findViewById(R.id.culture_startDate);
        end = (EditText) findViewById(R.id.culture_endDate);

        updateBn = (Button) findViewById(R.id.updateBn);

        culID = cul_id;
        System.out.println(culID);

        imgUrl.setText(cul_picpath);
        name.setText(cul_name);
        desc.setText(cul_desc);
        culPlace.setText(place);
        start.setText(start_date);
        end.setText(end_date);

        updateBn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                img = imgUrl.getText().toString();
                Cname = name.getText().toString();
                Cdesc = desc.getText().toString();
                Cplace = culPlace.getText().toString();
                Cstart = start.getText().toString();
                Cend = end.getText().toString();

                if(img.isEmpty() || Cname.isEmpty() || Cdesc.isEmpty() || Cplace.isEmpty() || Cstart.isEmpty() || Cend.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "빈칸을 채워주세요.", Toast.LENGTH_SHORT).show();
                } else {
                    cultureUpdate();
                    Intent intent = new Intent(getApplicationContext(), ManagerCulture.class);
                    startActivity(intent);
                    finish();
                }
            }
        });
    }

    //문화생활 수정하기
    public void cultureUpdate() {
        new Thread() {
            public void run() {
                String culimg = imgUrl.getText().toString();
                try {
                    URL url = new URL("http://10.0.2.2:8080/adminCultureUpdate.php/");
                    HttpURLConnection http = (HttpURLConnection) url.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");


                    culimg = URLEncoder.encode(culimg, "utf-8");

                    StringBuffer buffer = new StringBuffer();
                    buffer.append("key").append("=").append(culID).append("/").append(culimg).append("/")
                            .append(name.getText().toString()).append("/").append(desc.getText().toString()).append("/")
                            .append(culPlace.getText().toString()).append("/").append(start.getText().toString()).
                            append("/").append(end.getText().toString()).append("/");

                    OutputStreamWriter outStream = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    outStream.write(buffer.toString());
                    outStream.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String str = "";

                    while ((str = reader.readLine()) != null) {
                        builder.append(str);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                Intent intent = new Intent(context, ManagerCulture.class);
                startActivity(intent);
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
