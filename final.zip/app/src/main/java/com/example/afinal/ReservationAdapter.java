package com.example.afinal;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

public class ReservationAdapter extends BaseAdapter {

    TextView cul_name, place, resDate, resTime, resPerson;

    private ArrayList<ReservationItem> items = new ArrayList<ReservationItem>();

    public ReservationAdapter() {

    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public Object getItem(int position) {
        return items.get(position);
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final Context context = parent.getContext();

        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.reservation_item, parent, false);
        }
        cul_name = (TextView) convertView.findViewById(R.id.cul_name);
        place = (TextView) convertView.findViewById(R.id.place);
        resDate = (TextView) convertView.findViewById(R.id.resDate);
        resTime = (TextView) convertView.findViewById(R.id.resTime);
        resPerson = (TextView) convertView.findViewById(R.id.resPerson);

        ReservationItem item = items.get(position);

        cul_name.setText(item.getCul_name());
        place.setText(item.getPlace());
        resDate.setText(item.getResDate());
        resTime.setText(item.getResTime());
        resPerson.setText(item.getResPerson());

        return convertView;
    }
}
