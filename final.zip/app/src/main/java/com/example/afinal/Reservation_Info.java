package com.example.afinal;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

public class Reservation_Info extends AppCompatActivity {

    private Context context = this;

    private static final String TAG_RESULTS = "result";
    private static final String TAG_ID = "res_num";
    private static final String TAG_CULTUREID = "cul_id";
    private static final String TAG_NAME = "cul_name";
    private static final String TAG_PLACE = "place";
    private static final String TAG_DATE = "resDate";
    private static final String TAG_TIME = "resTime";
    private static final String TAG_PERSON = "res_people";

    ArrayList<HashMap<String, String>> reservationList;
    ListView list;

    ReservationAdapter adapter = new ReservationAdapter();

    String user_id, user_pw, culName, culPlace, culResDate, culResTime, culResPerson;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reservation_info);

        //툴바관련
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(false); // 기존 title 지우기
        actionBar.setDisplayHomeAsUpEnabled(true); // 뒤로가기 버튼 만들기

        Intent intent = getIntent();
        user_id = intent.getStringExtra("user_id");
        user_pw = intent.getStringExtra("user_pw");

        culName = intent.getStringExtra("cul_name");
        culPlace = intent.getStringExtra("place");
        culResDate = intent.getStringExtra("resDate");
        culResTime = intent.getStringExtra("resTime");
        culResPerson = intent.getStringExtra("resPerson");

        list = (ListView) findViewById(R.id.reservation_lv);
        reservationList = new ArrayList<HashMap<String, String>>();

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                HashMap<String, String> map = (HashMap<String, String>) list.getItemAtPosition(position);
                String cul_id = map.get(TAG_CULTUREID);
                System.out.println("cul_id=" + cul_id);

                FrameLayout container = new FrameLayout(Reservation_Info.this);
                FrameLayout.LayoutParams params = new  FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                //params에 margin 추가
                params.leftMargin = getResources().getDimensionPixelSize(R.dimen.dialog_margin);
                params.rightMargin = getResources().getDimensionPixelSize(R.dimen.dialog_margin);

                final AlertDialog.Builder builder = new AlertDialog.Builder(Reservation_Info.this);
                builder.setTitle("예약 관리");
                builder.setMessage("예약을 취소하시겠습니까?");
                builder.setView(container);    //AlertDialog에 적용하기

                builder.setPositiveButton("예약취소하기", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        reservationDelete(cul_id);
                        Toast.makeText(getApplicationContext(), "취소완료. 해당페이지를 나갔다 돌아오세요.", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setNegativeButton("돌아가기", null);
                builder.show();
            }
        });
        resSelect();
    }

    //예약취소(삭제)
    public void reservationDelete(String cul_id) {
        new Thread() {
            public void run() {
                try {
                    URL url = new URL("http://10.0.2.2:8080/reservationDelete.php/");
                    HttpURLConnection http = (HttpURLConnection) url.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");

                    StringBuffer buffer = new StringBuffer();
                    buffer.append("key").append("=").append(cul_id);

                    OutputStreamWriter outStream = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    outStream.write(buffer.toString());
                    outStream.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String str;

                    while ((str = reader.readLine()) != null) {
                        builder.append(str + "\n");
                    }
                    String resultData = builder.toString();
                    adapter.notifyDataSetChanged();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

    //예약리스트 보여주기
    protected void showList(ArrayList<String[]> al) {
        try {
            for (int i = 0; i < al.size(); i++) {
                String cul_id = null;
                String cul_name = null;
                String place = null;
                String resDate = null;
                String resTime = null;
                String resPerson = null;
                for(int j = 0; j < al.get(i).length; j++){
                    cul_id = al.get(i)[0];
                    cul_name = al.get(i)[1];
                    place = al.get(i)[2];
                    resDate = al.get(i)[3];
                    resTime = al.get(i)[4];
                    resPerson = al.get(i)[5];
                }

                HashMap<String, String> cul = new HashMap<String, String>();

                cul.put(TAG_CULTUREID, cul_id);
                cul.put(TAG_NAME, cul_name);
                cul.put(TAG_PLACE, place);
                cul.put(TAG_DATE, resDate);
                cul.put(TAG_TIME, resTime);
                cul.put(TAG_PERSON, resPerson);

                reservationList.add(cul);
            }
            ListAdapter adapter = new SimpleAdapter(
                    Reservation_Info.this, reservationList, R.layout.reservation_item,
                    new String[]{TAG_NAME, TAG_PLACE, TAG_DATE, TAG_TIME, TAG_PERSON},
                    new int[]{ R.id.cul_name, R.id.place, R.id.resDate, R.id.resTime, R.id.resPerson}
            );
            list.setAdapter(adapter);
        } catch (Exception e) {
            Log.d(TAG_ID, "showResult : ", e);
        }
    }

    //예약리스트 보여주기
    public void resSelect(){
        new Thread(){
            public  void run(){
                try {
                    URL url = new URL("http://10.0.2.2:8080/reservation_info.php/");
                    HttpURLConnection http = (HttpURLConnection) url.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type","application/x-www-form-urlencoded");

                    StringBuffer buffer = new StringBuffer();
                    buffer.append("user_id").append("=").append(user_id);

                    OutputStreamWriter osw = new OutputStreamWriter(http.getOutputStream(), "utf-8");
                    osw.write(buffer.toString());
                    osw.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "utf-8");
                    final BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();

                    String str;
                    while ((str = reader.readLine()) != null ) {
                        builder.append(str);
                    }
                    String resultData = builder.toString();

                    final String[] sR1 = resultData.split("#");
                    ArrayList<String[]> result = new ArrayList<>();
                    for(String sR2 : sR1){
                        final String[] sR3 = sR2.split("///");
                        if(sR3.length > 1) {
                            result.add(sR3);
                            System.out.println("sR2=" + sR2);
                            String cul_name = sR3[0];
                            String place = sR3[1];
                            String resDate = sR3[2];
                            String resTime = sR3[3];
                            String resPerson = sR3[4];
                            System.out.println("sR3=" + sR3);
                        }
                    }
                    showList(result);
                }catch (Exception e){
                    Log.e("error","인터넷 문제 발생", e);
                }
            }
        }.start();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                Intent intent = new Intent(context, Mypage.class);
                intent.putExtra("user_id", user_id);
                intent.putExtra("user_pw", user_pw);
                startActivity(intent);
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
