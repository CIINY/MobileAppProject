package com.example.afinal.Manager;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.afinal.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

public class ManagerUserInquiry extends AppCompatActivity {

    private DrawerLayout mDrawerLayout;
    private Context context = this;

    String myJSON;

    JSONArray culture = null;
    ListView user_lv;
    ArrayList<HashMap<String, String>> userList;

    private static final String TAG_RESULTS = "result";
    private static final String TAG_USERID = "user_id";
    private static final String TAG_NAME = "name";
    private static final String TAG_REGDATE = "user_regdate";


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.manager_userinquiry);

        user_lv = (ListView) findViewById(R.id.user_lv);
        userList = new ArrayList<HashMap<String, String>>();
        getData("http://10.0.2.2:8080/selectUser.php");

        //툴바
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(false); // 기존 title 지우기
        actionBar.setDisplayHomeAsUpEnabled(true); // 뒤로가기 버튼 만들기

    }

    protected void showList() {
        try {
            JSONObject jsonObj = new JSONObject(myJSON);
            culture = jsonObj.getJSONArray(TAG_RESULTS);

            for (int i = 0; i < culture.length(); i++) {
                JSONObject c = culture.getJSONObject(i);
                String user_id = c.getString(TAG_USERID);
                String name = c.getString(TAG_NAME);
                String user_regdate = c.getString(TAG_REGDATE);

                HashMap<String, String> cul = new HashMap<String, String>();

                cul.put(TAG_USERID, user_id);
                cul.put(TAG_NAME, name);
                cul.put(TAG_REGDATE, user_regdate);

                userList.add(cul);
                System.out.println("이것은 reviewList: " + userList);
            }
            ListAdapter adapter = new SimpleAdapter(
                    ManagerUserInquiry.this, userList, R.layout.user_item,
                    new String[]{TAG_USERID, TAG_NAME, TAG_REGDATE},
                    new int[]{ R.id.user_id, R.id.name, R.id.user_regdate}
            );
            user_lv.setAdapter(adapter);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    public void getData(String url) {
        class GetDataJSON extends AsyncTask<String, Void, String> {
            @Override
            protected String doInBackground(String... params) {
                String uri = params[0];

                BufferedReader bufferedReader = null;
                try {
                    java.net.URL url = new URL(uri);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    StringBuilder sb = new StringBuilder();

                    bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));

                    String json;
                    while ((json = bufferedReader.readLine()) != null) {
                        sb.append(json + "\n");
                    }

                    return sb.toString().trim();
                } catch (Exception e) {
                    return null;
                }

            }
            @Override
            protected void onPostExecute (String result){
                myJSON = result;
                showList();
            }
        }
        GetDataJSON g = new GetDataJSON();
        g.execute(url);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                Intent intent = new Intent(context, ManagerMain.class);
                startActivity(intent);
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
