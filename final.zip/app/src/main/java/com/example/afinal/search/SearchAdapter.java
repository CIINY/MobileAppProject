package com.example.afinal.search;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.afinal.R;

import java.util.ArrayList;

public class SearchAdapter extends BaseAdapter {


    TextView cul_name, place, start_date, end_date;
    ImageView cul_picpath;

    ArrayList<Search> searchList = new ArrayList<Search>();

    public SearchAdapter() {

    }

    @Override
    public int getCount() {
        return searchList.size();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) { // 오르락 내리락 할때 안보이던 아이템들 불러오는거
        final int pos = position;
        final Context context = parent.getContext();

        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.search_item, parent, false);
        }

        cul_picpath = (ImageView) convertView.findViewById(R.id.cul_picpath);
        cul_name = (TextView) convertView.findViewById(R.id.cul_name);
        place = (TextView) convertView.findViewById(R.id.place);
        start_date = (TextView) convertView.findViewById(R.id.start_date);
        end_date = (TextView) convertView.findViewById(R.id.end_date);

        Search listItem = searchList.get(position);

        Glide.with(convertView).asBitmap().load(listItem.getCul_picpath()).into(cul_picpath);
        cul_name.setText(listItem.getCul_name());
        place.setText(listItem.getPlace());
        start_date.setText(listItem.getStart_date());
        end_date.setText(listItem.getEnd_date());

        return convertView;

    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public Object getItem(int position) {
        return searchList.get(position);
    }

    public void addItem(int cul_id, String cul_picpath, String cul_name, String place, String start_date, String end_date) {

        Search item = new Search();

        item.setCul_id(cul_id);
        item.setCul_picpath(cul_picpath);
        item.setCul_name(cul_name);
        item.setPlace(place);
        item.setStart_date(start_date);
        item.setEnd_date(end_date);

        searchList.add(item);
    }
}
