package com.example.afinal;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.afinal.dto.UserDto;
import com.example.afinal.search.SearchAdapter;
import com.google.android.material.navigation.NavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    private DrawerLayout mDrawerLayout;
    private Context context = this;

    String myJSON;

    private static final String TAG_RESULTS = "result";
    private static final String TAG_ID = "cul_id";
    private static final String TAG_IMAGE = "cul_picpath";
    private static final String TAG_NAME = "cul_name";
    private static final String TAG_PLACE = "place";
    private static final String TAG_DESC = "cul_desc";
    private static final String TAG_START = "start_date";
    private static final String TAG_END = "end_date";

    JSONArray culture = null;
    ArrayList<HashMap<String, String>> cultureList;
    ListView list;

    Button btnSearch;

    UserDto userDto;

    int count;
    Handler handler = new Handler();
    CultureListAdapter adapter = new CultureListAdapter();

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //로그인 정보 가져오기
        Intent intent = getIntent();
        String user_id = intent.getStringExtra("user_id");
        String user_pw = intent.getStringExtra("user_pw");
        userDto = (UserDto) intent.getSerializableExtra("obj");

        list = (ListView) findViewById(R.id.List_view);
        cultureList = new ArrayList<HashMap<String, String>>();
        getData("http://10.0.2.2:8080/PHP_connection.php");

        //문화생활 상세정보 페이지로 이동
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                HashMap<String,String> map = (HashMap<String,String>) list.getItemAtPosition(position);
                String cul_id = map.get(TAG_ID);
                String cul_picpath = map.get(TAG_IMAGE);
                String cul_name = map.get(TAG_NAME);
                String place = map.get(TAG_PLACE);
                String cul_desc = map.get(TAG_DESC);
                String start_date = map.get(TAG_START);
                String end_date = map.get(TAG_END);

                Intent intent = new Intent(getApplicationContext(), CultureDetail.class);
                intent.putExtra("cul_id", cul_id);
                intent.putExtra("cul_picpath", cul_picpath);
                intent.putExtra("cul_name", cul_name);
                intent.putExtra("place", place);
                intent.putExtra("cul_desc", cul_desc);
                intent.putExtra("start_date", start_date);
                intent.putExtra("end_date", end_date);

                intent.putExtra("user_id", user_id);
                startActivity(intent);
                finish();
            }
        });

        //툴바
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(false); // 기존 title 지우기
        actionBar.setDisplayHomeAsUpEnabled(true); // 뒤로가기 버튼 만들기
        actionBar.setHomeAsUpIndicator(R.drawable.ic_baseline_menu_24); //뒤로가기 버튼 이미지 지정

        //검색버튼
        btnSearch = findViewById(R.id.btnSearch);
        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent seaInt = new Intent(getApplicationContext(), com.example.afinal.search.SearchPage.class);
                seaInt.putExtra("user_id", user_id);
                startActivity(seaInt);
                finish();
            }
        });

        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);

        //네비게이션뷰에 회원아이디 보이게 하기
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        // xml 파일에서 넣어놨던 header 선언
        View header = navigationView.getHeaderView(0);
        // header에 있는 리소스 가져오기
        TextView text = (TextView) header.findViewById(R.id.navi_userID);
        text.setText(user_id);

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                int id = menuItem.getItemId();
                String title = menuItem.getTitle().toString();

                AlertDialog.Builder builder=new AlertDialog.Builder(context);
                builder.setTitle("Logout");
                builder.setMessage("로그아웃 하시겠습니까?");

                if (id == R.id.myPage) {
                    Intent mpInt=new Intent(context, Mypage.class);
                    mpInt.putExtra("user_id", user_id);
                    mpInt.putExtra("user_pw", user_pw);
                    startActivity(mpInt);
                    finish();
                } else if (id == R.id.mainPage) {
                    Toast.makeText(context, title + ": 현재페이지 입니다.", Toast.LENGTH_SHORT).show();
                } else if (id == R.id.logout) {
                    builder.setPositiveButton("예(YES)", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent=new Intent(context, Login.class);
                            startActivity(intent);
                            finish();
                        }
                    });
                    builder.setNegativeButton("취소(CANCEL)", null);
                    builder.show();
                }
                DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
                drawer.closeDrawer(GravityCompat.START);

                return true;
            }
        });


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home: { // 왼쪽 상단 버튼 눌렀을 때
                mDrawerLayout.openDrawer(GravityCompat.START);
                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }

    protected void showList() {
        try {
            JSONObject jsonObj = new JSONObject(myJSON);
            culture = jsonObj.getJSONArray(TAG_RESULTS);
            for (int i = 0; i < culture.length(); i++) {
                JSONObject c = culture.getJSONObject(i);
                String cul_id = c.getString(TAG_ID);
                String cul_picpath = c.getString(TAG_IMAGE);
                String cul_name = c.getString(TAG_NAME);
                String place = c.getString(TAG_PLACE);
                String cul_desc = c.getString(TAG_DESC);
                String start_date = c.getString(TAG_START);
                String end_date = c.getString(TAG_END);

                HashMap<String, String> cul = new HashMap<String, String>();

                cul.put(TAG_ID, cul_id);
                cul.put(TAG_IMAGE, cul_picpath);
                cul.put(TAG_NAME, cul_name);
                cul.put(TAG_PLACE, place);
                cul.put(TAG_DESC, cul_desc);
                cul.put(TAG_START, start_date);
                cul.put(TAG_END, end_date);
                cultureList.add(cul);
            }
            ListAdapter adapter = new SimpleAdapter(
                    MainActivity.this, cultureList, R.layout.list_item,
                    new String[]{TAG_IMAGE, TAG_NAME, TAG_PLACE, TAG_START, TAG_END},
                    new int[]{R.id.cul_picpath, R.id.cul_name, R.id.place, R.id.start_date, R.id.end_date}
            );
            list.setAdapter(adapter);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void getData(String url) {
        class GetDataJSON extends AsyncTask<String, Void, String> {
            @Override
            protected String doInBackground(String... params) {
                String uri = params[0];
                BufferedReader bufferedReader = null;
                try {
                    java.net.URL url = new URL(uri);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    StringBuilder sb = new StringBuilder();
                    bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String json;
                    while ((json = bufferedReader.readLine()) != null) {
                        sb.append(json + "\n");
                    }
                    return sb.toString().trim();
                } catch (Exception e) {
                    return null;
                }
            }
            @Override
            protected void onPostExecute (String result){
                myJSON = result;
                showList();
            }
        }
        GetDataJSON g = new GetDataJSON();
        g.execute(url);
    }
}
