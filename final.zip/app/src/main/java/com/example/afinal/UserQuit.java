package com.example.afinal;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class UserQuit extends AppCompatActivity {

    EditText etID, etPW;
    Button btnQiutCon, btnCancel;

    String userID, userPW;
    
    //로그인한 정보
    String user_id, user_pw;

    Handler handler = new Handler();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_quit);

        //로그인한 유저 정보 데이터 가져오는 부분
        Intent intent = getIntent();
        user_id = intent.getStringExtra("user_id");
        user_pw = intent.getStringExtra("user_pw");
        System.out.println("user_id=" + user_id);
        System.out.println("user_pw=" + user_pw);

        etID = (EditText)findViewById(R.id.etIDCon);
        etPW = (EditText)findViewById(R.id.etPWCon);

        btnQiutCon = (Button)findViewById(R.id.btnQuit);
        btnCancel = (Button)findViewById(R.id.btnCancel);

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Mypage.class);
                startActivity(intent);
                finish();
            }
        });

        btnQiutCon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                userID = etID.getText().toString();
                userPW = etPW.getText().toString();

                if (userID.equals(user_id) && userPW.equals(user_pw)) {
                    userDelete();
                } else if(user_id.isEmpty() || user_pw.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "빈칸을 입력하세요.", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "아이디, 비밀번호가 틀렸습니다.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void userDelete() {
        new Thread() {
            public void run() {
                try {
                    URL url = new URL("http://10.0.2.2:8080/deleteUser.php/");
                    HttpURLConnection http = (HttpURLConnection) url.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");

                    StringBuffer buffer = new StringBuffer();
                    buffer.append("key").append("=").append(user_id);
                    System.out.println(user_id);

                    OutputStreamWriter outStream = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    outStream.write(buffer.toString());
                    outStream.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String str;

                    while ((str = reader.readLine()) != null) {
                        builder.append(str + "\n");
                    }
                    String resultData = builder.toString();
                    handler.post (new Runnable() {
                        @Override
                        public void run() {
                            Intent i = new Intent(getApplicationContext(), Login.class);
                            startActivity(i);
                            finish();
                            Toast.makeText(getApplicationContext(), "회원탈퇴가 완료 되었습니다.", Toast.LENGTH_LONG).show();
                        }
                    });
                } catch (Exception e) {

                    e.printStackTrace();
                }
            }
        }.start();
    }
}
